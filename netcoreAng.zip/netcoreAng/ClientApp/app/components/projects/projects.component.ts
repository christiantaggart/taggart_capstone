// import { Component } from '@angular/core';
//
// @Component({
//     selector: 'projects',
//     // templateUrl: './index.html',
//
//     templateUrl: './projects.component.html',
//     styleUrls: ['../app/app.component.css']
//     //ADD CAROSEL?
// })
// export class ProjectsComponent {
// }
